# v83d Leave-Camera/Pen-Out Grouped Cross-Validation

## Scope

This stage evaluates the supplemental grouped classifier using leave-camera/pen-out cross-validation. Each fold holds out one camera+pen group and trains on the remaining groups.

## Selected model

- Task: dominant_vs_other_2 grouped classification
- Feature set: visual-only
- Selection rule: best mean macro F1 across camera/pen holdouts
- Selected model: random_forest
- Folds: 6
- Mean macro F1: 0.582280
- Min/Max macro F1: 0.398176 / 0.718056
- Mean accuracy: 0.648309

## Interpretation

This is stronger generalization evidence than a single Split B validation/test result because it tests multiple camera/pen holdouts. If the fold scores vary strongly, this supports the earlier v83c finding that grouped classification is sensitive to camera/pen distribution.

## Claim boundary

- This remains a supplemental grouped classifier analysis.
- It does not replace the original 11-class task.
- It does not claim production-ready cross-camera behaviour recognition.
