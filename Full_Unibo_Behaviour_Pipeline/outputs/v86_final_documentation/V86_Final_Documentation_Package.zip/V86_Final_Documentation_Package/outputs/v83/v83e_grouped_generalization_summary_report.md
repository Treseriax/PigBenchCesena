# v83e Grouped Generalization Summary

## Main finding

The supplemental grouped behaviour classifier is substantially more learnable than the original 11-class task, but its evaluation depends on the split protocol.

## Results

- Split A grouped macro F1: 0.639560
- Split A grouped accuracy: 0.652439
- Split B official validation-selected macro F1: 0.238434
- Split B official validation-selected accuracy: 0.313084
- Leave-camera/pen-out CV mean macro F1: 0.582280
- Leave-camera/pen-out CV mean accuracy: 0.648309

## Interpretation

Split A shows strong grouped performance. Split B single validation/test selection shows instability, because the validation-selected model performs poorly on test while another exploratory test model performs much better. The leave-camera/pen-out CV gives stronger evidence by evaluating multiple camera/pen holdouts and shows acceptable grouped generalization.

## Claim boundary

- This is supplemental grouped behaviour classification.
- It does not replace the original 11-class behaviour task.
- It supports the conclusion that broader behaviour categories are more learnable than fine-grained 11-class labels under the current feature representation.
- It does not claim production-ready cross-camera behaviour recognition.
