# V86 Final Documentation Package

This package contains the final documentation and evidence summaries for the Unibo Pig Behaviour Analysis Pipeline.

Important claim boundary:
This project is not production-ready.
The project does not claim final automatic identity tracking.
The project does not claim a final pretrained VideoMAE model.
The grouped classifier does not replace the original 11-class behaviour classification task.
The 11-class task remains difficult and is documented with limitations.
